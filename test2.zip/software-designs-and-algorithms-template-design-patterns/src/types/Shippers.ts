import { AirEastShipper } from '../Shippers/AirEastShipper';
import { ChicagoSprintShipper } from '../Shippers/ChicagoSprintShipper';
import { PacificParcelShipper } from '../Shippers/PacificParcelShipper';

export type Shippers = AirEastShipper | ChicagoSprintShipper | PacificParcelShipper;
