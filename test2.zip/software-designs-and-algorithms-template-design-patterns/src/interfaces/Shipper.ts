import { ShipmentItem } from '../constants';

export interface IShipper {
  getCost(weight: number, shipmentItemType: ShipmentItem): number;
}
