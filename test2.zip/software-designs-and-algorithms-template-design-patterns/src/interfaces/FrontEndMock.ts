import { ShipmentData } from '../types/ShipmentData';

export interface IFrontEndMock {
  getShipmentData(): ShipmentData;
}
