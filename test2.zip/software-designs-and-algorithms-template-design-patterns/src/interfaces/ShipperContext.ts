import { IShipper } from './Shipper';

export interface IShipperContext extends IShipper {
  setShipper(zipCode: string): void;
}
