export interface IClient {
  shipItem(): string;
}
