export interface IShipment {
  ship(): string;

  getShipmentID(id: number): number;
}
