import { IClient } from './interfaces/Client';
import { FrontEndMock } from './FrontEndMock';
import { Shipment } from './Shipment';
import { ShipperContext } from './Shippers/ShipperContext';
import { ShipmentDecorator } from './ShipmentDecorator';

export class Client implements IClient {
  shipItem(): string {
    const frontEnd = new FrontEndMock();
    const data = frontEnd.getShipmentData();

    const shipperCtx = new ShipperContext();
    const shipment = new Shipment(data, shipperCtx);

    const decorated = new ShipmentDecorator(shipment, data.mark);
    return decorated.ship();
  }
}

const client: Client = new Client();

console.log(client.shipItem());
