import { IShipment } from './interfaces/Shipment';
import { IShipperContext } from './interfaces/ShipperContext';
import { ShipmentData } from './types/ShipmentData';
import { ShipmentItem } from './constants';
import { Letter } from './ShipmentItems/Letter';
import { Package as PackageItem } from './ShipmentItems/Package';
import { Oversize } from './ShipmentItems/Oversize';

export class Shipment implements IShipment {
  private static lastId = 0;

  private data: ShipmentData;
  private shipperCtx: IShipperContext;
  private shipmentId: number;

  constructor(data: ShipmentData, shipperCtx: IShipperContext) {
    this.data = data;
    this.shipperCtx = shipperCtx;
    this.shipmentId = this.getShipmentID(data.ShipmentId ?? 0);
  }

  ship(): string {
    // Pick shipper based on FromZipCode
    this.shipperCtx.setShipper(this.data.FromZipCode ?? '');

    const itemType = this.getShipmentItemType(this.data.Weight);
    const cost = this.shipperCtx.getCost(this.data.Weight, itemType);

    const from = `${this.data.FromAddress}${this.data.FromZipCode ? ' ' + this.data.FromZipCode : ''}`;
    const to = `${this.data.ToAddress} ${this.data.ToZipCode}`;

    const costFormatted = this.formatCurrency(cost);

    return `Shipment with the ID ${this.shipmentId} will be picked up from ${from} and shipped to ${to}\nCost = ${costFormatted}`;
  }

  getShipmentID(id: number): number {
    if (id && id > 0) return id;
    Shipment.lastId += 1;
    return Shipment.lastId;
  }

  private getShipmentItemType(weight: number): ShipmentItem {
    if (weight <= 15) return Letter.getType();
    if (weight <= 160) return PackageItem.getType();
    return Oversize.getType();
  }

  private formatCurrency(value: number): string {
    // round to 2 decimals and trim trailing zeros
    const fixed = value.toFixed(2);
    return fixed.replace(/\.00$/, '').replace(/(\.[1-9])0$/, '$1');
  }
}
