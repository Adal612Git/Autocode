export enum ShipmentItem {
  LETTER = 'letter',
  PACKAGE = 'package',
  OVERSIZE = 'oversize',
}

export enum MARKS {
  FRAGILE = '**MARK FRAGILE**',
  DO_NOT_LEAVE = '**MARK DO NOT LEAVE IF ADDRESS NOT AT HOME**',
  RETURN_RECEIPT_REQUESTED = '**MARK RETURN RECEIPT REQUESTED**',
}

