import { IShipper } from '../interfaces/Shipper';
import { ShipmentItem } from '../constants';

export class PacificParcelShipper implements IShipper {
  private static instance: PacificParcelShipper;

  static getInstance(): PacificParcelShipper {
    if (!this.instance) {
      this.instance = new PacificParcelShipper();
    }
    return this.instance;
  }
  getCost(weight: number, shipmentItemType: ShipmentItem): number {
    switch (shipmentItemType) {
      case ShipmentItem.LETTER:
        return 0.51 * weight;
      case ShipmentItem.PACKAGE:
        return 0.19 * weight;
      case ShipmentItem.OVERSIZE:
        return 0.19 * weight + 0.02 * weight; // 0.02 added per ounce in addition to package charge
      default:
        return 0.51 * weight;
    }
  }
}
