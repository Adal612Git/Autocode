import { IShipper } from '../interfaces/Shipper';
import { ShipmentItem } from '../constants';

export class AirEastShipper implements IShipper {
  private static instance: AirEastShipper;

  static getInstance(): AirEastShipper {
    if (!this.instance) {
      this.instance = new AirEastShipper();
    }
    return this.instance;
  }
  getCost(weight: number, shipmentItemType: ShipmentItem): number {
    switch (shipmentItemType) {
      case ShipmentItem.LETTER:
        return 0.39 * weight;
      case ShipmentItem.PACKAGE:
        return 0.25 * weight;
      case ShipmentItem.OVERSIZE:
        return 10 + 0.25 * weight; // $10 flat in addition to standard package charge
      default:
        return 0.39 * weight;
    }
  }
}
