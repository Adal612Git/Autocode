import { IShipperContext } from '../interfaces/ShipperContext';
import { IShipper } from '../interfaces/Shipper';
import { AirEastShipper } from './AirEastShipper';
import { ChicagoSprintShipper } from './ChicagoSprintShipper';
import { PacificParcelShipper } from './PacificParcelShipper';
import { ShipmentItem } from '../constants';

export class ShipperContext implements IShipperContext {
  private shipper: IShipper;

  constructor() {
    this.shipper = AirEastShipper.getInstance();
  }

  setShipper(zipCode: string): void {
    const first = (zipCode || '').trim()[0];
    if (first === '4' || first === '5' || first === '6') {
      this.shipper = ChicagoSprintShipper.getInstance();
    } else if (first === '7' || first === '8' || first === '9') {
      this.shipper = PacificParcelShipper.getInstance();
    } else {
      // Default to Air East for unknown/invalid zip codes or 1-3
      this.shipper = AirEastShipper.getInstance();
    }
  }

  getCost(weight: number, shipmentItemType: ShipmentItem): number {
    return this.shipper.getCost(weight, shipmentItemType);
  }
}
