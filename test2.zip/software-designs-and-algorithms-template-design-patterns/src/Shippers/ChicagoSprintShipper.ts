import { IShipper } from '../interfaces/Shipper';
import { ShipmentItem } from '../constants';

export class ChicagoSprintShipper implements IShipper {
  private static instance: ChicagoSprintShipper;

  static getInstance(): ChicagoSprintShipper {
    if (!this.instance) {
      this.instance = new ChicagoSprintShipper();
    }
    return this.instance;
  }
  getCost(weight: number, shipmentItemType: ShipmentItem): number {
    switch (shipmentItemType) {
      case ShipmentItem.LETTER:
        return 0.42 * weight;
      case ShipmentItem.PACKAGE:
        return 0.2 * weight;
      case ShipmentItem.OVERSIZE:
        return 0.2 * weight; // No extra charge over package rate
      default:
        return 0.42 * weight;
    }
  }
}
