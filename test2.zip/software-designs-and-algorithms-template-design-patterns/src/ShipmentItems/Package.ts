import { ShipmentItem } from '../constants';

export class Package {
  static getType(): ShipmentItem {
    return ShipmentItem.PACKAGE;
  }
}