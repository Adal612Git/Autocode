import { ShipmentItem } from '../constants';

export class Oversize {
  static getType(): ShipmentItem {
    return ShipmentItem.OVERSIZE;
  }
}