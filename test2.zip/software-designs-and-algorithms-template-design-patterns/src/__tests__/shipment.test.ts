import { Shipment } from '../../src/Shipment';
import { ShipperContext } from '../../src/Shippers/ShipperContext';
import { ShipmentDecorator } from '../../src/ShipmentDecorator';
import { MARKS } from '../../src/constants';
import type { ShipmentData } from '../../src/types/ShipmentData';

describe('Shipment', () => {
  const baseData: Omit<ShipmentData, 'FromZipCode' | 'Weight'> = {
    ShipmentId: 999,
    FromAddress: '12292 4th Ave SE, Bellevue, WA',
    ToAddress: '1313 Mockingbird Lane, Tulsa, OK',
    ToZipCode: '67721',
  };

  test('uses Air East by default and computes letter cost (0.39/oz)', () => {
    const data: ShipmentData = {
      ...baseData,
      FromZipCode: '12345', // Air East (1-3)
      Weight: 10, // Letter
    };
    const shipment = new Shipment(data, new ShipperContext());
    const out = shipment.ship();
    expect(out).toBe(
      'Shipment with the ID 999 will be picked up from 12292 4th Ave SE, Bellevue, WA 12345 and shipped to 1313 Mockingbird Lane, Tulsa, OK 67721\nCost = 3.9'
    );
  });

  test('uses Chicago Sprint for from zip starting with 4-6 and computes package cost', () => {
    const data: ShipmentData = {
      ...baseData,
      FromZipCode: '55555', // Chicago Sprint (4-6)
      Weight: 20, // Package
    };
    const shipment = new Shipment(data, new ShipperContext());
    const out = shipment.ship();
    // Chicago Sprint package rate = 0.20/oz -> 4
    expect(out.endsWith('Cost = 4')).toBe(true);
  });

  test('uses Pacific Parcel for from zip starting with 7-9 and computes oversize cost', () => {
    const data: ShipmentData = {
      ...baseData,
      FromZipCode: '92021', // Pacific Parcel (7-9)
      Weight: 200, // Oversize
    };
    const shipment = new Shipment(data, new ShipperContext());
    const out = shipment.ship();
    // Pacific Parcel oversize = (0.19 + 0.02) * 200 = 42
    expect(out.endsWith('Cost = 42')).toBe(true);
  });

  test('decorates output with selected marks in order', () => {
    const data: ShipmentData = {
      ...baseData,
      FromZipCode: '12345',
      Weight: 10,
      mark: [MARKS.FRAGILE, MARKS.DO_NOT_LEAVE, MARKS.RETURN_RECEIPT_REQUESTED],
    };
    const shipment = new Shipment(data, new ShipperContext());
    const decorated = new ShipmentDecorator(shipment, data.mark);
    const out = decorated.ship();

    const expectedBase =
      'Shipment with the ID 999 will be picked up from 12292 4th Ave SE, Bellevue, WA 12345 and shipped to 1313 Mockingbird Lane, Tulsa, OK 67721\nCost = 3.9';
    const expected = [
      expectedBase,
      MARKS.FRAGILE,
      MARKS.DO_NOT_LEAVE,
      MARKS.RETURN_RECEIPT_REQUESTED,
    ].join('\n');

    expect(out).toBe(expected);
  });

  test('falls back to Air East when FromZipCode is missing', () => {
    const data: ShipmentData = {
      ...baseData,
      Weight: 10, // Letter
    } as ShipmentData; // FromZipCode intentionally omitted
    const shipment = new Shipment(data, new ShipperContext());
    const out = shipment.ship();
    expect(out.endsWith('Cost = 3.9')).toBe(true);
  });
});

