import { MARKS } from '../constants';

export type ShipmentData = {
  ShipmentId?: number;
  FromAddress: string;
  ToAddress: string;
  Weight: number;
  FromZipCode?: string;
  ToZipCode: string;
  mark?: MARKS[] | MARKS;
};
