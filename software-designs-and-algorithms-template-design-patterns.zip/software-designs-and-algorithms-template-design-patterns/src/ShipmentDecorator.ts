import { IShipment } from './interfaces/Shipment';
import { MARKS } from './constants';

export class ShipmentDecorator implements Pick<IShipment, 'ship'> {
  private base: IShipment;
  private marks?: MARKS[] | MARKS;

  constructor(base: IShipment, marks?: MARKS[] | MARKS) {
    this.base = base;
    this.marks = marks;
  }

  ship(): string {
    const result = this.base.ship();
    if (!this.marks) return result;

    const marksArray = Array.isArray(this.marks) ? this.marks : [this.marks];
    const marksText = marksArray.join('\n');
    return `${result}\n${marksText}`;
  }
}
