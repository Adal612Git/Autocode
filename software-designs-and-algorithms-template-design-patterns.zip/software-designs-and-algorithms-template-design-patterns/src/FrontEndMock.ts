import { IFrontEndMock } from './interfaces/FrontEndMock';
import { ShipmentData } from './types/ShipmentData';
import { MARKS } from './constants';

export class FrontEndMock implements IFrontEndMock {
  getShipmentData(): ShipmentData {
    // Stubbed data; easy to swap with real front-end later
    return {
      ShipmentId: 0,
      FromAddress: '12292 4th Ave SE, Bellevue, WA',
      FromZipCode: '92021',
      ToAddress: '1313 Mockingbird Lane, Tulsa, OK',
      ToZipCode: '67721',
      Weight: 13,
      mark: [MARKS.FRAGILE, MARKS.DO_NOT_LEAVE, MARKS.RETURN_RECEIPT_REQUESTED],
    };
  }
}
