import { ShipmentItem } from '../constants';

export class Letter {
  static getType(): ShipmentItem {
    return ShipmentItem.LETTER;
  }
}